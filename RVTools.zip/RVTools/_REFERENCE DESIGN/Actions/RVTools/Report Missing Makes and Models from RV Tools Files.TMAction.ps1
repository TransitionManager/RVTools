<####### TransitionManager Action Script ######

	ActionName			= Report Missing Makes and Models from RV Tools Files 
	ProviderName		= RVTools 
	CredentialName 		= 

	Description			= Runs a Make/Model check of Hosts from an RV Tools File in the TMD_Files\Input\RVTools folder.
#>

## End of TM Configuration, Begin Script

<#
 # Summarize Makes and Models from RV Tools files to Output Folder

 	This script reads a folder of RVTools files and summarizes the list of manufacturers
	 and models they collectively require.  It also queries a given TM server for the
	 list of existing manufacturers and models, providing a report of the ones that already
	 exist.  The resulting spreadsheet can be used to create the missing makes and models.
#>

## TransitionManager Server Details
$TMServer = ([uri]$ActionRequest.options.callback.siteUrl).Host
$TMProject = $ActionRequest.options.apiAction.project.name
$TMProvider = $ActionRequest.options.apiAction.provider.name

## Use a default credential
$TMCredential = Get-StoredCredential 'ME'

## Create a File Path for the Provider
$ProviderInputFolder = Join-Path $userPaths.input $TMProvider
$ProviderOutputFolder = Join-Path $userPaths.Output $TMProvider
Test-FolderPath -FolderPath $ProviderInputFolder
Test-FolderPath -FolderPath $ProviderOutputFolder

## Create Arrays to hold objects
$RVToolsManufacturers = [System.Collections.ArrayList]::new()
$RVToolsManuModels = [System.Collections.ArrayList]::new()

## Get the list of Excel files
$RVToolsFiles = Get-ChildItem -Path $ProviderInputFolder

## Iterate over each RV Tools files
foreach ($RVToolsFile in $RVToolsFiles) {
	
	Write-Host 'Reading RV Tools file: ' -NoNewline
	Write-Host $RVToolsFile -ForegroundColor Yellow

	## Attempt to use an open package and Select-Object -unique.  Didn't work so well on the Models
	## Attach to the Excel 
	$ExcelPackage = Open-ExcelPackage -Path $RVToolsFile.FullName
	
	## Get the Excel Sheet
	$vHost = Import-Excel -WorksheetName 'vHost' -ExcelPackage $ExcelPackage -DataOnly
	
	$Manufacturers = $vHost.Vendor
	$Models = $vhost.Model

	## Close the Excel File
	Close-ExcelPackage -ExcelPackage $ExcelPackage

	## Combine Manufacturer and Model into a consolidated object
	$ManuModels = for ($i = 0; $i -lt $Models.Count; $i++) {
		[PSCustomObject]@{
			Manufacturer = $Manufacturers[$i]
			Model        = $Models[$i]
		}
	}
	
	## Get Unique Manufacturers and ManuModels
	$UniqueManufacturers = $Manufacturers | Select-Object -Unique
	$UniqueManuModels = $ManuModels | Group-Object 'Manufacturer', 'Model' | ForEach-Object {
		$_.Group | Select-Object -Property 'Manufacturer', 'Model' -First 1
	}

	## Add the Unique items from this file to the aggregate list
	$UniqueManufacturers | ForEach-Object { [void]$RVToolsManufacturers.Add($_) }
	$UniqueManuModels | ForEach-Object { [void]$RVToolsManuModels.Add($_) }

	Write-Host ("`tFound a total of " + $UniqueManufacturers.Count + ' Manufacturers and ' + $UniqueManuModels.Count + ' Manu/Models in this file')

	# Working but itterative heavy logic
	# ## Open the Excel file to get the Hosts Tab
	# $RVToolsHosts = Import-ExcelFile -FilePath $RVToolsFile -SheetName 'vHost'
	
	# ## Collect the list of Vendors/Manufacturers
	# $RVToolsHosts | ForEach-Object {
		
	# 	## Add the Manufacturer to the list if it isn't in it already
	# 	if ($RVToolsManufacturers.Manufacturer -notcontains $_.Vendor) { 
	# 		$RVToolsManufacturers += [PSCustomObject]@{
	# 			Manufacturer = $_.Vendor 
	# 		}
			
	# 	}
		
	# 	## Add the Model/Manufacturer to the list if it isn't in it already
	# 	if ($RVToolsManuModels.Model -notcontains $_.Model) { 
	# 		$RVToolsManuModels += [PSCustomObject]@{
	# 			Manufacturer = $_.Vendor
	# 			Model        = $_.Model 
	# 		}
			
	# 	}
	# }
}

## Reduce the Arrays to a unique RVTools set of values
$UniqueRVToolsManufacturers = $RVToolsManufacturers | Select-Object -Unique | ForEach-Object { [PSCustomObject]@{
		Manufacturer = $_
	} 
}
$UniqueRVToolsManuModels = $RVToolsManuModels | Group-Object 'Manufacturer', 'Model' | ForEach-Object {
	$_.Group | Select-Object -Property 'Manufacturer', 'Model' -First 1
}

## Save the Manufacturers and Models as is for now
$Timestamp = Get-Date -Format FileDateTimeUniversal
$UniqueRVToolsManufacturers | ConvertTo-CSV | Set-Content -Path (Join-Path $ProviderOutputFolder ('RVTools_Manufacturers_' + $Timestamp + '.csv')) -Force
$UniqueRVToolsManuModels | ConvertTo-CSV | Set-Content -Path (Join-Path $ProviderOutputFolder ('RVTools_Models' + $Timestamp + '.csv')) -Force

## Write Progress
Write-Host 'Done Evaluating RV Tools files'
Write-Host "`tTotal Manufacturers Found:"$UniqueRVToolsManufacturers.Count
Write-Verbose ($UniqueRVToolsManufacturers | ConvertTo-Json )
Write-Host "`tTotal Models Found:"$UniqueRVToolsManuModels.Count
Write-Verbose ($UniqueRVToolsManuModels | ConvertTo-Json )

## Connect to the Server
Write-Host 'Connecting to TransitionManager'

New-TMSession -Server $TMServer -Credential $TMCredential
Enter-TMProject -ProjectName $TMProject

## Get the list of existing manufacturers and models
Write-Host 'Getting a list of Manufacturers and Models from TransitionManager'
$TMManufacturers = Get-TMManufacturer
$TMModels = Get-TMModel

## Compare the Manufacturers in the list from RV Tools to produce a 'Missing' list
$MissingManufacturers = @()
$MissingModels = @()

## Begin Comparison of RV Tools Manufacturers and Models to the TM Server List
Write-Host 'Beginning Comparison of TM Manufacturer and Model vs RV Tools Data'

## Check the RV Tools Manufacturers against the TM List
$UniqueRVToolsManufacturers | ForEach-Object {

	## Check the TM Manufacturers list
	if ($TMManufacturers -notcontains $_.Manufacturer) {
		$MissingManufacturers += $_
	}
}

## Check the RV Tools Models against the TM List
$UniqueRVToolsManuModels | ForEach-Object {

	## Check the TM Manufacturers list
	if ($TMModels.modelName -notcontains $_.Model) {
		$MissingModels += $_
	}
}

## Create a filename for the Manufacturers and Models Files
$MissingManufacturersFile = Join-Path $ProviderOutputFolder ('Missing_Manufacturers_' + $Timestamp + '.csv')
$MissingModelsFile = Join-Path $ProviderOutputFolder ('Missing_Models_' + $Timestamp + '.csv')

## Save the Missing Manufacturers
$FilesWritten = $false
if ($MissingManufacturers) {
	$FilesWritten = $true
	$MissingManufacturers | ConvertTo-CSV | Set-Content -Path $MissingManufacturersFile -Force
	Invoke-Item $MissingManufacturersFile
} 

## Save the Missing  Models
if ($MissingModels) {
	$FilesWritten = $true
	$MissingModels | ConvertTo-CSV | Set-Content -Path $MissingModelsFile -Force
	Invoke-Item $MissingModelsFile
}

## If a File has been written
if ($FilesWritten) {
	Write-Host 'Missing Manufacturer and Model reports have been written to ' -NoNewline 
	Write-Host $ProviderOutputFolder -ForegroundColor Yellow
} 
else {
	Write-Host 'All Manufacturers and Models listed in RV Tools Data are present on the TM Server' -ForegroundColor Cyan
	
}


