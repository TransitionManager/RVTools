<#
	OVERVIEW
		This script intends to run recipes in the project that you are loading.
		All bundles, events, and/or recipes _must_ exist on the TM instance.

		This script is not intended to be run directly, but as part of the 
		Reference Design Import process.  Use at your discression.

		Since this script is run in the setup process, it runs inside of a 
		connected TMSession, etc.  This script does NOT set this connection up for you.

#>

## Apply the Getting Started
$BundleName = 'Getting Started'
$EventName = 'Getting Started'
# $RecipeName = 'Getting Started - RVTools'

## Create the Getting Started Bundle
$Bundle = [PSCustomObject]@{
	name           = $BundleName
	description    = 'Getting Started with Reference Designs'
	useForPlanning = $true
}
$GettingStartedBundle = New-TMBundle -Bundle $Bundle -PassThru

## Create the Getting Started Event
$GettingStartedEvent = [PSCustomObject]@{
	name        = $EventName
	description = 'Getting Started with Reference Designs'
	moveBundle     = @($GettingStartedBundle.id)
}
New-TMEvent -InputObject $GettingStartedEvent

## Publish the Recipe
# Publish-TMRecipe -Name $RecipeName

## Invoke the Getting Started Recipe
# Invoke-TMRecipe -Name $RecipeName -EventName $EventName -PublishTasks -UseWip
