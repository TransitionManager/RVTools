/*
        Script Name: RVTools - Discovery - Import Inventory - v4.5.2
        Extension Type: Import Data Script

        SUMMARY
        Import Inventory for a vCenter using an RVTools Excel Export.

        DESCRIPTION
        Import an export of vCenter from an RVTools file.  This import script will create or update matching
        asset records and dependencies.  This highly configurable script offers many different asset classes
        and dependency types.

        RELEASE DETAILS
            Author: TransitionManager Automation Development <support@transitionmanager.com>
            Script Version: v4.5.2
            Release Date: 2022-01-20

            (c) Copyright 2022 by Transitional Data Services. All Rights Reserved.

        REQUIREMENTS
            Minimum TM Version: 5.0.2
            RVTools Minimum Version: v3.8

            FIELD REQUIREMENTS:
                Application:
                    Used for Types:
                        - vCenter Server
                        - vCenter Cluster

                Device:
                    Used for Types:
                        - VMHosts
                        - VirtualMachines
                        - VirtualMachinesTemplates
                        - VirtualNetworks
                        - VirtualDistributedSwitch

                Storage:
                    Used for Types:
                        - Datastores
                        - vDisks

        CONFIGURATION SETTINGS
            This script uses a Config object to enable, disable and adjust how features of this script works.
            Each configuration item has description, comment, valid values and usage instructions inline.

        TESTING APPROVALS
            - TM Version: {tmVersion}, {testDate}, {Summary}

*/

// This script uses 'lookup', which needs to be enabled to function.
enable lookup



// Configuration and settings to be used throughout the script
Map config = [

    // Data Source Identification for Tagging assets
    dataSource: [
        name: 'RVTools',

        // Tags will be prefixed with 'Data Type:'
        // These labele ONE asset, keep them singular
        typeTags: [
            cluster:    'vCenter Cluster',
            host:       'vCenter VMHost',
            vm:         'vCenter VM',
            template:   'vCenter Template',
            vdisk:      'vCenter vDisk',
            partition:  'vCenter vPartition',
            datastore:  'vCenter Datastore',
            storage:    'vCenter Storage',
            subnet:     'Subnet',
        ]
    ],

    // Determines which asset types will be processed by the script
    // Each Data Type is processed
    // All of the <object>s are processed, use plural
    process: [

        // Enable Type desired          // Default Settings
        clusters:               true,   // true
        hosts:                  true,   // true
        vms:                    true,   // true
        vdisks:                 true,   // true
        partitions:             true,   // true
        datastores:             true,   // true
        subnets:                false,  // Requires TM Extension: 'Subnets'
    ],

    // Determines if a VM can be found by only its name
    matchVMOnNameAlone:         true,

    // Determines if a Host can be found by only its name
    matchHostOnNameAlone:       true,

    // Define default values for new asset records
    assetDefaults: [

        // Define the bundles new assets are created in
        // <one-object> (singular), belongs to a Bundle (Pluralized)
        bundles: [
            vm:               'DS Inbox - RVTools',
            template:         'vCenter Templates',
            cluster:          'vCenter Clusters',
            host:             'vCenter VMHosts',
            vdisk:            'vCenter vDisks',
            partition:        'vCenter vPartitions',
            datastore:        'vCenter Datastores',
        ],

        // Define the desired make and model for VMs
        vms: [
            manufacturer: 'VMware',
            model: 'VM',

            // RV Tools lists 10 'Source Network' Fields
            // Use this group of settings to define 0-10 networks
            // and store them in custom field Device[{prefix} n]
            vmSourceNetwork: [

                // Enable and Disable this import feature
                enabled: false,

                // Provide the standard prefix part of the field label
                prefix: 'Source Network',

                // How many "Source Network"s to read and map as a colum
                start: 1,   // Default: 1
                end: 3      // Default: 3

                // Using Default Settings, your Device will expect 3 fields:
                //      'Source Network 1'
                //      'Source Network 2'
                //      'Source Network 3'
            ]

        ]
    ],

    // The newer versions of RVTools that have differing column headers in some cases
    newerRVToolsVersions: [
        '4.1.3.0',
        '4.1.4.0',
    ]
]

// A cache object to store data throughout the script's execution
Map cache = [
    rvToolsFileVersion: '',
    sourceDocumentName: '',

    // Collect IPs and Device Mac addresses across Worksheets
    deviceIps:[:],
    deviceMacs:[:],
    deviceVlans:[:],

    clusters: [:],
    networkVlans: [:],
    vmToCluster: [:],
    deviceToVlan: [:],
    devicesWithRawDisk: [],
    devicesWithConnectedCDs: [:],
    devicesWithSharedBus: [],
    devicesWithLockedMemoryAtMax: [],

    // Needed to cache new storage hosts because the whenNotFound isn't working correctly on 5.0.3
    newVMs: [:],
]

//************************************
// Helper Functions
//***********************************/
def simplifyToolsVersion = { longToolsVersion ->
    // Return the trimmed version
    if (lToolsVersion == '2,147,483,647') {
        return 'Open VMTools Version'
    } else {
        return longToolsVersion.tokenize(',')[0]
    }
}

//************************************
// Batch Loading Order
//***********************************/
domain Application
domain Device
domain Database
domain Storage
domain Dependency

//////////////////////////////
//  vMetaData
//////////////////////////////
sheet 'vMetaData'
read labels
iterate {
    // Cache the vCenter server name and RV Tools version to be used later in the script
    extract 'Server' set vMetadataServer
    extract 'RVTools version' set vMetadataRvToolsVersion
    cache.sourceDocumentName = 'RV Tools vCenter Server: ' + vMetadataServer
    cache.rvToolsFileVersion = vMetadataRvToolsVersion
}

//////////////////////////////
//  vPort & dvPort
//////////////////////////////
if (config.process.subnets) {
    sheet 'vPort'
    read labels
    iterate {
        // Set the domain
        domain Device

        // Create a entry for the VLAN number, for the cluster-portgroup
        extract 'Host' set hostName
        extract 'Cluster' set clusterName
        extract 'Port Group' set portGroupName
        extract 'VLAN' transform with replaceAll(', ', '') set vlanNumber

        // Create a Key for the Cluster/PortGroup Pair
        set clusterPortGroupTag = clusterName + '||' + portGroupName

        // If the VLAN is not ZERO or empty
        if (vlanNumber != '0' && vlanNumber != '') {
            // If the VLAN is not already cached in the map
            if (!cache.networkVlans.containsKey(clusterPortGroupTag)) {
                // Add the VLAN id to the network list cache.
                cache.networkVlans.put(clusterPortGroupTag, vlanNumber)
            }
        }
    }

    sheet 'dvPort'
    read labels
    iterate {
        // Set the domain
        domain Device

        // Create a entry for the VLAN number, for the cluster-portgroup
        extract 'Port' set portName
        extract 'Switch' set switchName
        extract 'VLAN' transform with replaceAll(', ', '') set vlanNumber

        // Create a Key for the Cluster/PortGroup Pair
        set switchPortName = switchName + '||' + portName

        // If the VLAN is not ZERO or empty
        if (vlanNumber != '0' && vlanNumber != '') {
            // If the VLAN is not already cached in the map
            if (!cache.networkVlans.containsKey(switchPortName)) {
                // Add the VLAN id to the network list cache.
                cache.networkVlans.put(switchPortName, vlanNumber)
            }
        }
    }
}

//////////////////////////////
//  Clusters
//////////////////////////////
if (config.process.clusters) {
    sheet 'vCluster'
    read labels
    iterate {
        // Set the domain
        domain Application
        extract 'Name' transform with prepend('VM Cluster: ') set clusterNameWithLabel load 'Name'
        load 'Source Document' with cache.sourceDocumentName
        load 'appVendor' with config.assetDefaults.vms.manufacturer

        // Build up the Cluster description
        extract 'numEffectiveHosts' set numEffectiveHosts
        extract 'Effective Cpu' set effectiveCpu
        extract 'Effective Memory' set effectiveMemory
        extract 'Num VMotions' set numVMotions

        set clusterDesc with \
            'VMware Cluster (# effect hosts: ' + numEffectiveHosts \
            + ', effective CPU: ' + effectiveCpu \
            + ', effective Memory: ' + effectiveMemory + 'MB' \
            + ', # of vMotions: ' + numVMotions

        load 'Description' with clusterDesc
        load 'Vendor' with config.assetDefaults.vms.manufacturer
        load 'Bundle' with config.assetDefaults.bundles.cluster
        load 'Validation' with 'Validated'

        load 'DSLS-RVTools' with NOW
        tagAdd 'Data Source: ' + config.dataSource.name
        tagAdd 'Type: ' + config.dataSource.typeTags.cluster

        // Find the Cluster
        find Application by \
            'Vendor' eq config.assetDefaults.vms.manufacturer \
            and 'Name' eq clusterNameWithLabel \
            into 'id'
        elseFind Application by \
            'Name' eq clusterNameWithLabel \
            into 'id'
    }
}

//////////////////////////////
//  Hosts
//////////////////////////////
if (config.process.hosts) {
    // Process Tab: vSC_VMK
    //         This tab is where the IP address details for the Hosts are stored.
    //         Execution of this iterate loop only creates cached items that are later pulled in
    //          when the vHosts tab is read (last)
    sheet 'vSC_VMK'
    read labels
    iterate {
        // Attach to an existing import record
        extract 'Host' set hostName

        // If there is already an entry for this hostname in the Device/IP Set Cache
        extract 'IP Address' set hostIp
        if (cache.deviceIps.containsKey(hostName)) {
            // Add the New IP to the Host's IP Set
            cache.deviceIps[hostName].add(hostIp)
            log 'Adding to IP cache for ' + hostName
        } else {
            // No Cached Item existed, make a new one, with the HostIP
            Set deviceIpSet = [hostIp]
            cache.deviceIps.put(hostName, deviceIpSet)
        }

        // If there is already an entry for this hostname in the Device/Mac Set Cache
        extract 'Mac Address' set hostMac
        if (cache.deviceMacs.containsKey(hostName)) {
            // Add the New IP to the Host's Mac Set
            cache.deviceMacs[hostName].add(hostMac)
        } else {
            // No Cached Item existed, make a new one, with the HostMac
            Set deviceMacSet = [hostMac]
            cache.deviceMacs.put(hostName, deviceMacSet)
        }
    }

    //
    // Process Tab: vPort
    //         This tab contains a list of the Physical Hosts and the Physical ports on them, in addition to the virtual swithes
    //         Execution of this iterate loop only creates cached items that are later pulled in
    //          when the vHosts tab is read (last)
    sheet 'vPort'
    read labels
    iterate {
        // Attach to an existing import record
        extract 'Host' set hostName

        extract 'VLAN' set hostVlan
        if (cache.deviceVlans.containsKey(hostName)) {
            // Add the New IP to the Host's IP Set
            cache.deviceVlans[hostName].add(hostVlan)
            log 'Adding to VLAN cache for ' + hostName
        } else {
            // No Cached Item existed, make a new one, with the HostIP
            Set deviceVlanSet = [hostVlan]
            cache.deviceVlans.put(hostName, deviceVlanSet)
        }
    }

    // Process the vHosts tab (Primary Host Asset details)
    sheet 'vHost'
    read labels
    iterate {
        domain Device

        // Attach to an existing import record
        extract 'Host' set tempHostName
        lookup 'Alternate Name' with tempHostName

        // Start loading the Host Details
        set hostName with tempHostName.substring(0, tempHostName.indexOf('.'))
        load 'Name' with hostName
        load 'Alternate Name' with tempHostName
        load 'Source Document' with cache.sourceDocumentName
        extract 'Object ID' set objectId
        extract '# Cores' load 'Processor - Count'
        extract '# Memory' load 'Memory - Total'
        extract 'Service tag' load 'serialNumber' set serialNo
        extract 'ESX Version' load 'os' set esxVersion
        extract 'Datacenter' set datacenter

        load 'moveBundle' with config.assetDefaults.bundles.host

        // Locate the Room the device is in
        find Room by 'location' eq 'VMware' and 'roomName' eq datacenter into 'roomSource'
        whenNotFound 'roomSource' create {
            'location' 'VMware'
            'roomName' datacenter
        }

        // Manufacturer
        extract 'Vendor' set mfg load 'manufacturer'
        find Manufacturer by 'name' eq mfg into 'manufacturer'
        whenNotFound 'manufacturer' create { 'name' mfg }
        
        // Save the manufacturer find results to use later in whenNotFound create statements
        def hostManufacturerFind = FINDINGS

        // Model
        extract 'Model' set model load 'Model'
        find Model by \
            'modelName' eq model \
            and 'manufacturer' eq mfg \
            into 'model'
        elseFind Model by \
            'modelName' eq model \
            into 'model'

        // Save the Model find results to use later in whenNotFound create statements
        def hostModelFind = FINDINGS

        // TODO: Waiting on Ticket TM-20132 correcting for this functionality
        // In the meantime, the workaround is to NOT attempt creation of the Model
        // whenNotFound 'model' create {
        //     'modelName' model;
        //     'manufacturer' mfg;
        //     'assetType' 'Server';
        //     'usize' 1
        // }

        // Set some Virtual Properties
        load 'Virtual - Is Virtual' with 'No'
        load 'DSID-vCenter' with objectId
        extract 'Cluster' transform with prepend('VM Cluster: ') set clusterNameWithLabel load 'Virtual - Cluster Name'

        // CPU Model contains a string which is split on @.  Before the @ is the Model, after is the Speed.  Available in TM v4.5
        extract 'CPU Model' set cpuModel

        // Create Description
        extract '# NICs' load 'Network - NIC Count' set numNics
        extract '# VMs' set numVMs
        extract '# vCPUs' set numVCpus
        extract 'vRAM' set vRam
        def hostDesc = 'Cluster Host (Nics:' + numNics \
            + ', # of VMs:' + numVMs \
            + ', # of vCPUs:' + numVCpus \
            + ', RAM:' + vRam + 'MB)'
        load 'Description' with hostDesc
        load 'DSLS-RVTools' with NOW

        // Collect the cached IP, Macs and VLans
        ipSet = cache.deviceIps[hostName]
        macSet = cache.deviceMacs[hostName]
        vlanSet = cache.deviceVlans[hostName]

        // Load each field with the collected list
        load 'IP Address' with ipSet?.join(', ')
        load 'Network - Mac Address' with macSet?.join(', ')
        load 'Network - Source VLAN' with vlanSet?.join(', ')

        // Shorten the IP, Mac and VLans if they're too long
        def ipLen = DOMAIN.ipAddress?.length()
        def ipString = DOMAIN.ipAddress
        if (ipLen > 1000) {
            element ipString transform with ellipsis(999) load 'IP Address'
        }

        // Test Mac Length
        def macLen = DOMAIN.'Network - Mac Address'?.length()
        def macString = DOMAIN.'Network - Mac Address'
        if (macLen > 255) {
            element macString transform with ellipsis(254) load 'Network - Mac Address'
        }

        // Test Mac Length
        def vlanLen = DOMAIN.'Network - Source VLAN'?.length()
        def vlanString = DOMAIN.'Network - Source VLAN'
        if (vlanLen > 255) {
            element vlanString transform with ellipsis(254) load 'Network - Source VLAN'
        }

        tagAdd 'Data Source: ' + config.dataSource.name
        tagAdd 'Type: ' + config.dataSource.typeTags.host

        // Find the Asset
        find Device by \
            'Name' eq hostName \
            and 'Manufacturer' eq mfg \
            and 'Model' eq model \
            and 'External Ref Id' eq objectId \
            into 'id'
        elseFind Device by \
            'Name' eq hostName\
            and 'Manufacturer' eq mfg \
            and 'External Ref Id' eq objectId \
            into 'id'
        elseFind Device by \
            'Name' eq hostName \
            and 'External Ref Id' eq objectId \
            into 'id'
        elseFind Device by \
            'External Ref Id' eq objectId \
            into 'id'
        elseFind Device by \
            'Name' eq hostName \
            and 'Manufacturer' eq mfg \
            and 'Model' eq model \
            into 'id'
        elseFind Device by \
            'Name' eq hostName \
            and 'Manufacturer' eq mfg \
            into 'id'
        elseFind Device by \
            'Name' eq hostName \
            and 'serialNumber' eq serialNo \
            into 'id'
        if (config.matchHostOnNameAlone == true) {
            elseFind Device by \
                'Name' eq hostName \
                into 'id'
        }
        set thisHost with DOMAIN

        // Add a Dependency if there is
        extract 'Cluster' set clusterName
        if ((config.process.clusters) && (clusterName != null) && (clusterName != '')) {
            domain Dependency
            
            // The Cluster is the Asset
            load 'asset' with clusterNameWithLabel
            find Application by \
                'Name' eq clusterNameWithLabel \
                and 'Vendor' eq config.assetDefaults.vms.manufacturer \
                into 'asset'
            elseFind Application by \
                'Name' eq clusterNameWithLabel \
                into 'asset'
            whenNotFound 'asset' create {
                'Name' clusterNameWithLabel
                'Vendor' config.assetDefaults.vms.manufacturer
                'Bundle' config.assetDefaults.bundles.cluster
            }

            // The Host is the Dependent
            load 'dependent' with hostName

            find Device by \
                'DSID-vCenter' with objectId \
                into 'dependent'
            elseFind Device by \
                'Name' eq hostName \
                into 'dependent'
            
            
            whenNotFound 'dependent' create {
                'DSID-vCenter' objectId
                'Name' hostName
                'Manufacturer' hostManufacturerFind
                'Model' hostModelFind
                'Bundle' config.assetDefaults.bundles.host
            }

            // Dependency Properties
            load 'type' with 'Cluster Runs On'
            load 'status' with 'Validated'
            load 'dataFlowFreq' with 'constant'

            // Comment
            load 'comment' with 'From RV Tools: ' + NOW
        }
    }
}

//////////////////////////////
//  vDisks
//////////////////////////////
if (config.process.vdisks) {
    
    
    
    
    // Read vDisk from the vDisk Sheet
    sheet 'vDisk'
    read labels
    iterate {
        // Set the domain
        domain Storage

        extract 'VM' set vmName
        extract 'Disk' set diskName
        extract 'VM ID' set vmID
        extract 'VM UUID' set vmUUID
        extract 'Path' set path
        extract 'Raw' set raw

        init 'moveBundle' with config.assetDefaults.bundles.vdisk

        // Handle Version Specific Column Naming
        if (config.newerRVToolsVersions.contains(cache.rvToolsFileVersion)) {
            extract 'Capacity MiB'  transform with replaceAll(', ', '') defaultValue(0) set diskCapacity load 'Space - Provisioned'
        } else {
            extract 'Capacity MB'  transform with replaceAll(', ', '') defaultValue(0) set diskCapacity load 'Space - Provisioned'
        }

        set dataStoreName with path.substring(1, path.indexOf(']'))
        set uniqueDiskName with vmName + '-' + diskName

        load 'Name' with uniqueDiskName
        load 'Source Document' with cache.sourceDocumentName
        load 'Scale' with 'MB'
        load 'FS Type' with 'VMware vDisk'
        load 'DSLS-RVTools' with NOW

        tagAdd 'Data Source: ' + config.dataSource.name
        tagAdd 'Type: ' + config.dataSource.typeTags.vdisk

        // Find the Asset
        find Storage by \
            'Name' eq uniqueDiskName \
            and 'Space - Provisioned' eq diskCapacity \
            and 'FS Type' eq 'VMware vDisk' \
            into 'id'
        elseFind Storage by \
            'Name' eq uniqueDiskName \
            and 'FS Type' eq 'VMware vDisk' \
            into 'id'
        elseFind Storage by \
            'Name' eq uniqueDiskName \
            and 'Space - Provisioned' eq diskCapacity \
            into 'id'
        elseFind Storage by 'Name' eq uniqueDiskName into 'id'

        // Find the VM
        if (config.process.vms) {
            domain Dependency
            
            // VM is the Asset
            load 'asset' with vmName
            find Device by 'Name' eq vmName and 'DSID-vCenter' eq vmID and 'DSID-VMwareUUID' eq vmUUID into 'asset'
            whenNotFound 'asset' create {
                'Name' vmName
                'Bundle' config.assetDefaults.bundles.vm
                'Device Type' 'VM'
                'DSID-vCenter' vmID
                'DSID-VMwareUUID' vmUUID
            }
            
            // VM is the Asset
            load 'dependent' with vmName
            find Storage by \
                'Name' eq uniqueDiskName \
                and 'Space - Provisioned' eq diskCapacity \
                and 'FS Type' eq 'VMware vDisk' \
                into 'dependent'
            whenNotFound 'dependent' create {
                'Name' uniqueDiskName
                'Bundle' config.assetDefaults.bundles.vdisk
                'Space - Provisioned' diskCapacity
                'FS Type' 'VMware vDisk'
            }

            // Create Dependency   VM to vDisk
            load 'type' with 'VM-vDisk'
            load 'status' with 'Validated'
            load 'dataFlowFreq' with 'constant'
            load 'comment' with 'From RV Tools: ' + NOW
        }

        // Find the Datastore
        if (config.process.datastores && path) {
            domain Dependency
            
            // Asset is the vDisk
            load 'asset' with uniqueDiskName
            find Storage by \
                'Name' eq uniqueDiskName \
                and 'Space - Provisioned' eq diskCapacity \
                and 'FS Type' eq 'VMware vDisk' \
                into 'asset'
            whenNotFound 'asset' create {
                'Name' uniqueDiskName
                'Bundle' config.assetDefaults.bundles.vdisk
                'Space - Provisioned' diskCapacity
                'FS Type' 'VMware vDisk'
            }

            // Dependent is the Datastore
            set dataStoreName with path.substring(1, path.indexOf(']'))
            load 'dependent' with dataStoreName
            find Storage by 'Name' eq dataStoreName and 'FS Type' eq 'Datastore' into 'dependent'
            whenNotFound 'dependent' create {
                'Name' dataStoreName
                'FS Type' 'Datastore'
                'Bundle' config.assetDefaults.bundles.datastore
            }
            load 'type' with 'vDisk-vDatastore'
            load 'status' with 'Validated'
            load 'dataFlowFreq' with 'constant'
            load 'comment' with 'From RV Tools: ' + NOW
        }
    }
}

//////////////////////////////
//  VMs
//////////////////////////////
if (config.process.vms) {
    // Read RAW disk data from the vDisk Sheet
    // Store the details in the device cache for later use
    sheet 'vDisk'
    read labels

    iterate {
        // Get the VM Name
        extract 'VM' set vmName

        // Extract and handle RAW disk mode
        extract 'Raw' set rawDiskMode

        // If this line is for a RAW disk
        if (rawDiskMode == 'True') {
            // Add this VM name to the list of 'Has Raw Disk Mode'
            cache.devicesWithRawDisk.addAll(vmName)
        }

        // Extract and handle Shared Bus data
        extract 'Shared Bus' set sharedBus

        // If this line is for a RAW disk
        if (sharedBus != 'noSharing') {
            // Add this VM name to the list of 'Has Raw Disk Mode'
            cache.devicesWithSharedBus.addAll(vmName)
        }
    }

    // Collect details on the Memory Reservation Locks (Associated to Direct Path I/O tagging)
    sheet 'vMemory'
    read labels

    iterate {
        // Get the VM Name
        extract 'VM' set vmName

        // Extract and handle RAW disk mode
        extract 'Memory Reservation Locked To Max' set memoryLockedToMax

        // If this line is for a RAW disk
        if (memoryLockedToMax == 'True') {
            // Add this VM name to the list of 'Has Raw Disk Mode'
            cache.devicesWithLockedMemoryAtMax.addAll(vmName)
        }
    }

    // Read CD data from the vCD Sheet
    // Store the details in the device cache for later use
    sheet 'vCD'
    read labels

    iterate {
        extract 'Connected' set cdConnected
        extract 'Starts Connected' set cdStartsConnected
        extract 'Device Type' set cdDeviceType

        // If this line is for a RAW disk
        if ((cdConnected == 'True' || cdStartsConnected == 'True') && cdDeviceType.substring(0, 3) == 'ISO') {
            // Get the VM Name
            extract 'VM' set vmName

            // Add this VM name to the list of 'Has Raw Disk Mode'
            // cache.devicesWithConnectedCDs.addAll(vmName)
            cache.devicesWithConnectedCDs.put(vmName, cdDeviceType)
        }
    }

    sheet 'vInfo'
    read labels
    iterate {
        // Set the domain
        domain Device

        // Basic Values
        load 'Source Document' with cache.sourceDocumentName
        extract 'VM' load 'Name' set vmName
        extract 'VM ID' set objectId load 'DSID-vCenter'
        extract 'Template' set template
        extract 'DNS Name' load 'Network - Hostname' set dnsName
        extract 'Powerstate' load 'Virtual - Power State'
        extract 'CPUs' load 'Processor - Count' set cpu
        extract 'Memory' load 'Memory - Total' set memory
        extract 'NICs' load 'Network - NIC Count'
        extract 'Disks' load 'Disks - Count'
        extract 'Datacenter' set datacenter
        extract 'OS according to the VMware Tools' load 'OS' set os
        extract 'VM UUID' load 'Serial #' set vmUUID
        extract 'Path' set path
        extract 'Host' set host
        if (path) {
            set dataStore with path.substring(1, path.indexOf(']'))
        }

        load 'Manufacturer' with 'VMware'
        load 'Network - Hostname' with dnsName
        load 'Model' with 'VM'
        load 'Device Type' with 'VM'
        load 'DSID-VMwareUUID' with vmUUID
        load 'Virtual - Is Virtual' with 'Yes'
        extract 'HW version' load 'Virtual - Hardware Version'

        extract 'Connection state' load 'Virtual - Connection State'
        extract 'Guest state' load 'Virtual - Guest State'
        extract 'VI SDK Server' load 'DSEP-vCenter' set vCenterServer
        extract 'VM ID' load 'DSID-vCenter' set vmID
        extract 'Resource pool' load 'Virtual - Resource Pool'
        load 'Validation' with 'Validated'
        load 'DSLS-RVTools' with NOW

        // Collect and load the Device.'Source Network n' field from the vInfo.'Network #n' field
        if (config.assetDefaults.vms.vmSourceNetwork.enabled) {
            def start = config.assetDefaults.vms.vmSourceNetwork.start
            def end = config.assetDefaults.vms.vmSourceNetwork.end

            // Loop from Start to End
            for (i = start; i < end; i++) {
                // Compute the names of the xls field and the Asset Field
                def xlsColumnName = 'Network #' + i
                def assetFieldName = config.assetDefaults.vms.vmSourceNetwork.prefix + ' ' + i

                // Extract and Load the data
                extract xlsColumnName load assetFieldName
            }
        }

        // Add the RDM Disk tag if the VM has a Raw Disk
        if (cache.devicesWithRawDisk.contains(vmName)) {
            load 'Disks - Raw Mode' with 'True'
        } else {
            load 'Disks - Raw Mode' with 'False'
        }

        // Add the Shared Bus field if the device Shares a bus
        if (cache.devicesWithSharedBus.contains(vmName)) {
            load 'Disks - Shares Bus' with 'True'
        } else {
            load 'Disks - Shares Bus' with 'False'
        }

        // Add the ISO tag if the VM has a Raw Disk
        if (cache.devicesWithConnectedCDs.keySet().contains(vmName)) {
            isoName = cache.devicesWithConnectedCDs[vmName]
            load 'Disks - ISO Attached' with isoName
        } else {
            load 'Disks - ISO Attached' with 'No ISO Attached'
        }

        // Handle Version Specific Column Naming
        if (config.newerRVToolsVersions.contains(cache.rvToolsFileVersion)) {
            extract 'Provisioned MiB' load 'Disks - Total Provisioned'
            extract 'In Use MiB' load 'Disks - Total Used'
        } else {
            extract 'Provisioned MB' load 'Disks - Total Provisioned'
            extract 'In Use MB' load 'Disks - Total Used'
        }

        // // Locate the Room the device is in
        find Room by 'location' eq 'VMware' and 'roomName' eq datacenter into 'roomSource'
        whenNotFound 'roomSource' create {
            'location' 'VMware'
            'roomName' datacenter
        }

        tagAdd 'Data Source: ' + config.dataSource.name
        tagAdd 'Type: ' + config.dataSource.typeTags.vm

        // Find the asset
        find Device by \
            'Name' eq vmName \
            and 'Network - Hostname' eq dnsName \
            and 'DSID-vCenter' eq objectId \
            and 'DSEP-vCenter' eq vCenterServer \
            into 'id'

        elseFind Device by \
            'Name' eq vmName \
            and 'DSID-vCenter' eq objectId \
            and 'DSEP-vCenter' eq vCenterServer \
            into 'id'

        elseFind Device by \
            'Name' eq vmName \
            and 'Network - Hostname' eq dnsName \
            and 'DSEP-vCenter' eq vCenterServer \
            into 'id'

        elseFind Device by \
            'Name' eq vmName \
            and 'DSID-vCenter' eq objectId \
            and 'DSEP-vCenter' eq vCenterServer \
            into 'id'

        elseFind Device by \
            'DSID-vCenter' eq objectId \
            and 'DSEP-vCenter' eq vCenterServer \
            into 'id'

        if (config.matchVMOnNameAlone == true) {
            elseFind Device by \
                'Name' eq vmName \
                into 'id'
        }

        if (FINDINGS.size() == 0) { init 'moveBundle' with config.assetDefaults.bundles.vm }
        if (template == 'True') { load 'moveBundle' with config.assetDefaults.bundles.template }
        set thisVM with DOMAIN

        // Prepare to create a VM Runs On dependency.  The cluster field may be blank.
        extract 'Cluster' set clusterName
        if(config.process.clusters || config.process.hosts){
            if (clusterName && (clusterName != '')) {
                // Prepend the cluster name
                extract 'Cluster' transform with prepend('VM Cluster: ') set clusterNameWithLabel

                // Find the "Bottom" Asset
                domain Application
                load 'Name' with clusterNameWithLabel
                load 'Vendor' with config.assetDefaults.vms.manufacturer
                find Application by 'Name' eq clusterNameWithLabel and 'Vendor' eq config.assetDefaults.vms.manufacturer into 'id'
                elseFind Application by 'Name' eq clusterNameWithLabel into 'id'
                set thisCluster with DOMAIN
                ignore record

                domain Dependency with thisVM 'VM Runs On' thisCluster
                load 'status' with 'Validated'
                load 'dataFlowFreq' with 'constant'
                load 'comment' with 'From RV Tools' + NOW
            } else {
                // The Cluster field was blank.  Assign teh ependency to the host.
                domain Device
                load 'Name' with host
                find Device by 'Name' eq host into 'id'
                set thisHost with DOMAIN
                ignore record

                domain Dependency with thisVM 'VM Runs On' thisHost
                load 'status' with 'Validated'
                load 'dataFlowFreq' with 'constant'
                load 'comment' with 'From RV Tools' + NOW
            }
        }

        // Dependency to the Data Store
        // Find the Datastore
        if (dataStore && config.process.datastores) {
            domain Storage
            load 'Name' with dataStore
            load 'FS Type' with 'Datastore'
            find Storage by 'Name' eq dataStore and 'FS Type' eq 'Datastore' into 'id'
            set thisDatastore with DOMAIN
            ignore record

            domain Dependency with thisVM 'VM-vDatastore' thisDatastore
            load 'status' with 'Validated'
            load 'dataFlowFreq' with 'constant'
            load 'comment' with 'From RV Tools: ' + NOW
        }
    }

    // Tab: vCPU - VM Guest Related CPU info
    sheet 'vCPU'
    read labels
    iterate {
        // Set the domain
        domain Device

        extract 'VM ID' set vmID
        lookup 'DSID-vCenter' with vmID
        if (LOOKUP.found()) {
            extract 'CPUs' load 'Processor - Count'
            extract 'Sockets' load 'Processor - Socket Count'
            extract 'Cores p/s' load 'Processor - Cores Per Proc'
        }
    }

    // Tab: vNetwork - VM Guest Related IP and Mac address info
    sheet 'vNetwork'
    read labels
    iterate {
        // Set the domain
        domain Device

        extract 'VM' set vmName

        extract 'VM ID' set vmID
        lookup 'DSID-vCenter' with vmID
        if (LOOKUP.found()) {
            extract 'Adapter' set adaptor
            extract 'Network' set network
            extract 'Mac Address' set macAddress
            load 'Network - Mac Address' transform with append(', ', macAddress)

            // Load the Network Adaptor Fields
            load 'Network - Adaptor' transform with append(', ', adaptor)
            load 'Network - vNetwork' transform with append(', ', network)

            // Collect IP Addresses
            List ipAddresses = []

            // Handle Version Specific Column Naming
            if (config.newerRVToolsVersions.contains(cache.rvToolsFileVersion)) {
                extract 'IPv4 Address' set ipv4Address
                extract 'IPv6 Address' set ipv6Address

                ipAddresses.add(ipv4Address)
                ipAddresses.add(ipv6Address)
            } else {
                extract 'IP Address' set ipAddr
                ipAddresses.add(ipAddr)
            }

            // Load the IP Addresses into the field
            load 'IP Address' transform with append(', ', ipAddresses.join(', '))

            // Extract and handle Direct IO Path data
            extract 'Direct Path IO' set directIOPath

            // If the device has Direct Path IO, and the Memory is locked to the maximum reservation
            if (directIOPath == 'True' && cache.devicesWithLockedMemoryAtMax.contains(vmName)) {
                load 'Disks - Direct Path IO' with 'True'
            } else {
                load 'Disks - Direct Path IO' with 'False'
            }
        }
    }

    // Tab: vTools - VM Tools Data for VM Record
    sheet 'vTools'
    read labels
    iterate {
        // Set the domain
        domain Device

        extract 'VM ID' set vmID
        extract 'VM UUID' set vmUUID
        lookup 'DSID-vCenter' with vmID
        if (LOOKUP.found()) {
            extract 'Tools' load 'Virtual - Tools Status'
            extract 'Tools Version' set longToolsVersion
            if (longToolsVersion) {
                set toolsVersion with simplifyToolsVersion(longToolsVersion)
                load 'Virtual - Tools Version' with toolsVersion
            }

            // Take advantage of this processing loop to fix up the IPs collected
            // during the vNetwork sheet

            // Creates the field if it doesn't already exist
            load 'IP Address' transform with append('', '')
            load 'Network - Mac Address' transform with append('', '')

            // Get IP Address field Length
            def ipLen = DOMAIN.ipAddress.length()
            def ipString = DOMAIN.ipAddress

            // Check for over 1000 characters
            if (ipLen > 1000) {
                element ipString transform with ellipsis(999) load 'IP Address'
            }

            // Check MAC Length
            def macLen = DOMAIN.'Network - Mac Address'?.length()
            def macString = DOMAIN.'Network - Mac Address'
            if (macLen > 255) {
                element macString transform with ellipsis(254) load 'Network - Mac Address'
            }

            // Check the Existing Asset Record for Virtual - Power State and Tools Status
            find Device \
                by 'DSID-vCenter' eq vmID \
                and 'Serial #' eq vmUUID \
                fetch 'Virtual - Tools Status', 'Virtual - Power State' \
                set deviceRecord
        }
    }
}

//////////////////////////////
//  Data Stores
//////////////////////////////
if (config.process.datastores) {
    // Process Tab: vDatastore
    //         This tab is where the Data Stores are listed
    sheet 'vDatastore'
    read labels
    iterate {
        // Set the domain
        domain Storage
        load 'Source Document' with cache.sourceDocumentName
        extract 'Name' load 'Name' set datastoreName
        extract 'Hosts' set hosts
        extract 'Cluster name' transform with prepend('VM Cluster: ') set clusterNameWithLabel

        // Handle Version Specific Column Naming
        if (config.newerRVToolsVersions.contains(cache.rvToolsFileVersion)) {
            extract 'In Use MiB' transform with replaceAll(', ', '') defaultValue(0) load 'Space - Used'
            extract 'Capacity MiB' transform with replaceAll(', ', '') defaultValue(0) load 'Space - Provisioned' set datastoreSize
        } else {
            extract 'In Use MB' transform with replaceAll(', ', '') defaultValue(0) load 'Space - Used'
            extract 'Capacity MB' transform with replaceAll(', ', '') defaultValue(0) load 'Space - Provisioned' set datastoreSize
        }

        load 'Scale' with 'MB'
        load 'FS Type' with 'Datastore'

        load 'DSLS-RVTools' with NOW

        load 'Bundle' with config.assetDefaults.bundles.datastore
        tagAdd 'Data Source: ' + config.dataSource.name
        tagAdd 'Type: ' + config.dataSource.typeTags.datastore

        // Find Storage Asset
        find Storage by \
            'Name' eq datastoreName \
            and 'Space - Provisioned' eq datastoreSize \
            and 'FS Type' eq 'Datastore' \
            into 'id'

        elseFind Storage by \
            'Name' eq datastoreName \
            and 'FS Type' eq 'Datastore' \
            into 'id'

        elseFind Storage by \
            'Name' eq datastoreName \
            and 'Space - Provisioned' eq datastoreSize \
            into 'id'
        set thisDatastore with DOMAIN

        // Add a Dependency if there is
        extract 'Cluster name' set clusterName
        if (config.process.clusters && clusterName) {
            // Top Asset: the Cluster
            domain Application
            load 'Name' with clusterNameWithLabel
            load 'Vendor' with config.assetDefaults.vms.manufacturer
            tagAdd 'Data Source: ' + config.dataSource.name
            tagAdd 'Type: ' + config.dataSource.typeTags.cluster
            find Application by 'Name' eq clusterNameWithLabel and 'Vendor' eq config.assetDefaults.vms.manufacturer into 'id'
            elseFind Application by 'Name' eq clusterNameWithLabel into 'id'
            set thisCluster with DOMAIN
            ignore record

            domain Dependency with thisCluster 'Cluster-vDatastore' thisDatastore
            load 'status' with 'Validated'
            load 'dataFlowFreq' with 'constant'
            load 'comment' with 'From RV Tools: ' + NOW
        }

        if (config.process.hosts) {
            // If there is a list, or just a single value
            if (hosts && hosts != ''){
                
                // Treat the hosts field as a Comma Separated String
                List hostList = hosts.tokenize(',')
                for (host in hostList) {
                    String tempHostName = host.trim()
                    String hostName = tempHostName.substring(0, tempHostName.indexOf('.'))
                    // This dependency is created 'manually' because it's inside of a loop and reasigning the DOMAIN to a variable more than once is not permitted.
                    domain Dependency
                    load 'asset' with hostName
                    find Device by 'Name' eq hostName into 'asset'
                    elseFind Device by 'Alternate Name' eq hostName into 'asset'
                    whenNotFound 'asset' create {
                        'Name' hostName
                        'Bundle' config.assetDefaults.bundles.host
                    }

                    load 'dependent' with datastoreName
                    find Storage by 'Name' eq datastoreName and 'FS Type' eq 'Datastore' into 'dependent'
                    elseFind Storage by 'Name' eq datastoreName into 'dependent'
                    whenNotFound 'dependent' create {
                        'Name' datastoreName
                        'FS Type' 'Datastore'
                        'Bundle' config.assetDefaults.bundles.datastore
                    }

                    load 'type' with 'VMHost-vDatastore'
                    load 'status' with 'Validated'
                    load 'dataFlowFreq' with 'constant'
                    load 'comment' with 'From RV Tools: ' + NOW
                }
            } 
        }
    }
}

//////////////////////////////
//  Partitions
//////////////////////////////
if (config.process.partitions) {
    sheet 'vPartition'
    read labels
    iterate {
        // Set the domain
        domain Storage

        extract 'VM' set vmName
        extract 'VM ID' set vmId
        extract 'Disk' set diskName

        // Handle Version Specific Column Naming
        if (config.newerRVToolsVersions.contains(cache.rvToolsFileVersion)) {
            extract 'Capacity MiB'  transform with replaceAll(', ', '') defaultValue(0) set diskCapacity load 'Space - Provisioned'
            extract 'Free MiB'  transform with replaceAll(', ', '')  defaultValue(0) set diskFree
        } else {
            extract 'Capacity MB'  transform with replaceAll(', ', '') defaultValue(0) set diskCapacity load 'Space - Provisioned'
            extract 'Free MB'  transform with replaceAll(', ', '')  defaultValue(0) set diskFree
        }

        set uniqueDiskName with vmName + '-' + diskName

        load 'Name' with uniqueDiskName
        load 'Source Document' with cache.sourceDocumentName
        load 'Scale' with 'MB'
        load 'FS Type' with 'VMware vPartition'

        load 'Bundle' with config.assetDefaults.bundles.partition

        load 'DSLS-RVTools' with NOW
        tagAdd 'Data Source: ' + config.dataSource.name
        tagAdd 'Type: ' + config.dataSource.typeTags.partition

        // Find the Asset
        find Storage by \
            'Name' eq uniqueDiskName \
            and 'Space - Provisioned' eq diskCapacity \
            and 'FS Type' eq 'VMware vPartition' \
            into 'id'

        elseFind Storage by \
            'Name' eq uniqueDiskName \
            and 'FS Type' eq 'VMware vPartition' \
            into 'id'

        elseFind Storage by \
            'Name' eq uniqueDiskName \
            and 'Space - Provisioned' eq diskCapacity \
            into 'id'

        elseFind Storage by 'Name' eq uniqueDiskName into 'id'

        // Create a Dependency to the VM
        if (config.process.vms) {
            domain Dependency
            load 'type' with 'VM-vPartition'
            load 'status' with 'Validated'
            load 'dataFlowFreq' with 'constant'
            load 'comment' with 'From RV Tools: ' + NOW

            // Find "Bottom" Asset
            load 'dependent' with uniqueDiskName
            // tagAdd 'Data Source: ' + config.dataSource.name
            // tagAdd 'Type: ' + config.dataSource.typeTags.partition
            find Storage by 'Name' eq uniqueDiskName and 'FS Type' eq 'VMware vDisk' into 'dependent'
            whenNotFound 'dependent' create {
                'Name' uniqueDiskName
                'FS Type' 'VMware vDisk'
            }

            // Find VM Asset
            load 'asset' with vmName
            // tagAdd 'Data Source: ' + config.dataSource.name
            // tagAdd 'Type: ' + config.dataSource.typeTags.vm
            find Device by 'Name' eq vmName \
                and 'DSID-vCenter' eq vmId \
                and 'Manufacturer' eq config.assetDefaults.vms.manufacturer \
                and 'Model' eq config.assetDefaults.vms.model \
                into 'asset'   // Minimal VM details in this tab to use, not enough to permit creating with name alone
            whenNotFound 'asset' create {
                'Name' vmName
                'DSID-vCenter' vmId
                'Manufacturer' config.assetDefaults.vms.manufacturer
                'Model' config.assetDefaults.vms.model
                'Device Type' 'VM'
            }
        }
    }
}
