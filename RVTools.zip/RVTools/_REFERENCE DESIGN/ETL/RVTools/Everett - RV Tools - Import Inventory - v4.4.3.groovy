/**
        TransitionManager ETL Script
        Provider: RV Tools
        Script Name: RV Tools - Import 
        Script Version: v4.4.1
        Transition Manager Compatiblity:  4.7.3+
 */

// This script uses 'lookup', which needs to be enabled to function.
enable lookup

// A cache object to store data throughout the script's execution
Map cache = [
    rvToolsFileVersion: '',
    vCenterServerName: '',

    // Collect IPs and Device Mac addresses across Worksheets
    deviceIps:[:],
    deviceMacs:[:],
    deviceVLans:[:],

    clusters: [:],
    networkVlans: [:],
    vmToCluster: [:],
    deviceToVlan: [:],
    devicesWithRawDisk: [],
    devicesWithConnectedCDs: [:],
    devicesWithSharedBus: [],
    devicesWithLockedMemoryAtMax: [],
]

// Configuration and settings to be used throughout the script
Map config = [

    // Determines which asset types will be processed by the script
    process: [
        clusters:               false,   // true
        hosts:                  false,   // true
        vm:                     true,   // true
        vDisk:                  false,  // true
        storage:                false,   // true
        subnets:                false,   // true
    ],

    // Determines if a VM can be found by only its name
    matchVMOnNameAlone:         true,

    // Determines if a Host can be found by only its name
    matchHostOnNameAlone:       true,

    // Defines the custom names/properties defined in TransitionManager
    tmSettings: [
        templateBundleName:     'VM Template Device',
        clusterBundleName:      'VM Clusters',
        logicalStorageBundleName: 'OOS',
        newDeviceBundleName:    "New Devices from RVTools",
        vmWareMfg:              "VMware",
        vmWareModel:            "VM",
    ],
]

//************************************
// Helper Functions
//***********************************/
def simplifyToolsVersion = { longToolsVersion ->

    // Return the trimmed version
    if(lToolsVersion == '2,147,483,647' ) { 
        return "Open VMTools Version"
    } else {
        return longToolsVersion.tokenize(',')[0]
    }
}

//************************************
// Batch Loading Order
//***********************************/
domain Application
domain Device
domain Database
domain Storage
domain Dependency


//////////////////////////////
//  vMetaData
//////////////////////////////
sheet 'vMetaData'
read labels
iterate {

    // Cache the vCenter server name and RV Tools version to be used later in the script
    extract 'Server' set vMetadataServer
    extract 'RVTools version' set vMetadataRvToolsVersion
    cache.vCenterServerName = 'RV Tools vCenter Server: ' + vMetadataServer
    cache.rvToolsFileVersion = vMetadataRvToolsVersion
}

//////////////////////////////
//  vPort & dvPort
//////////////////////////////
if (config.process.subnets == true) {

    sheet 'vPort'
    read labels
    iterate {

        // Set the domain
        domain Device

        // Create a entry for the VLAN number, for the cluster-portgroup
        extract 'Host' set hostName
        extract 'Cluster' set clusterName
        extract 'Port Group' set portGroupName
        extract 'VLAN' transform with replaceAll(',','') set vlanNumber 

        // Create a Key for the Cluster/PortGroup Pair
        set clusterPortGroupTag = clusterName + '||'+ portGroupName

        // If the VLAN is not ZERO or empty
        if(vlanNumber != '0' && vlanNumber != ''){
            
            // If the VLAN is not already cached in the map
            if(!cache.networkVlans.containsKey(clusterPortGroupTag)){

                // Add the VLAN id to the network list cache.
                cache.networkVlans.put(clusterPortGroupTag, vlanNumber)
            }
        }
    }

    sheet 'dvPort'
    read labels
    iterate {

        // Set the domain
        domain Device

        // Create a entry for the VLAN number, for the cluster-portgroup
        extract 'Port' set portName
        extract 'Switch' set switchName
        extract 'VLAN' transform with replaceAll(',','') set vlanNumber

        // Create a Key for the Cluster/PortGroup Pair
        set switchPortName = switchName + '||'+ portName

        // If the VLAN is not ZERO or empty
        if(vlanNumber != '0' && vlanNumber != ''){
            
            // If the VLAN is not already cached in the map
            if(!cache.networkVlans.containsKey(switchPortName)){

                // Add the VLAN id to the network list cache.
                cache.networkVlans.put(switchPortName, vlanNumber)
            }
        }
    }
}

//////////////////////////////
//  Clusters
//////////////////////////////
if (config.process.clusters == true){
    sheet 'vCluster'
    read labels
    iterate {
        
        Map cluster = [:]

        // Set the domain
        domain Application
        extract 'Name' transform with prepend('VM Cluster: ') set clusterNameWithLabel load 'Name'
        load 'Source Document' with cache.vCenterServerName
        load 'appVendor' with config.tmSettings.vmWareMfg

        // Build up the Cluster description
        extract 'numEffectiveHosts' set numEffectiveHosts
        extract 'Effective Cpu' set effectiveCpu
        extract 'Effective Memory' set effectiveMemory
        extract 'Num VMotions' set numVMotions
        
        set clusterDesc with \
            "VMware Cluster (# effect hosts: " + numEffectiveHosts \
            + ", effective CPU: " + effectiveCpu \
            + ", effective Memory: " + effectiveMemory + "MB" \
            + ", # of vMotions: " + numVMotions

        load 'Description' with clusterDesc
        load 'Vendor' with config.tmSettings.vmWareMfg
        load 'Bundle' with config.tmSettings.clusterBundleName
        load 'Validation' with 'Validated'

        // load 'DSLastSeen-RVTools' with NOW

        // Find the Cluster
        find Application by \
            'Vendor' eq config.tmSettings.vmWareMfg \
            and 'Name' eq clusterNameWithLabel \
            into 'id'
        elseFind Application by \
            'Name' eq clusterNameWithLabel \
            into 'id'
    }
}

//////////////////////////////
//  Hosts
//////////////////////////////
if (config.process.hosts == true) {
    

    // Process Tab: vSC_VMK
    //         This tab is where the IP address details for the Hosts are stored.
    //         Execution of this iterate loop only creates cached items that are later pulled in
    //          when the vHosts tab is read (last)
    sheet 'vSC_VMK'
    read labels
    iterate {

        // Attach to an existing import record
        extract 'Host' set hostName

        // If there is already an entry for this hostname in the Device/IP Set Cache
        extract 'IP Address' set hostIp
        if(cache.deviceIps.containsKey(hostName)){
            
            // Add the New IP to the Host's IP Set
            cache.deviceIps[hostName].add(hostIp)
            log 'Adding to IP cache for ' + hostName

        } else {

            // No Cached Item existed, make a new one, with the HostIP
            Set deviceIpSet = [hostIp]
            cache.deviceIps.put(hostName,deviceIpSet)
        }

        // If there is already an entry for this hostname in the Device/Mac Set Cache
        extract 'Mac Address' set hostMac
        if(cache.deviceMacs.containsKey(hostName)){
            
            // Add the New IP to the Host's Mac Set
            cache.deviceMacs[hostName].add(hostMac)

        } else {

            // No Cached Item existed, make a new one, with the HostMac
            Set deviceMacSet = [hostMac]
            cache.deviceMacs.put(hostName, deviceMacSet)
        }
    }

    //
    // Process Tab: vPort
    //         This tab contains a list of the Physical Hosts and the Physical ports on them, in addition to the virtual swithes
    //         Execution of this iterate loop only creates cached items that are later pulled in
    //          when the vHosts tab is read (last)
    sheet 'vPort'
    read labels
    iterate {

        // Attach to an existing import record
        extract 'Host' set hostName
        
        extract 'VLAN' set hostVlan
        if(cache.deviceVlans.containsKey(hostName)){
            
            // Add the New IP to the Host's IP Set
            cache.deviceVlans[hostName].add(hostVlan)
            log 'Adding to VLAN cache for ' + hostName

        } else {

            // No Cached Item existed, make a new one, with the HostIP
            Set deviceVlanSet = [hostVlan]
            cache.deviceVlans.put(hostName, deviceVlanSet)
        }
    }

    // Process the vHosts tab (Primary Host Asset details)
    sheet 'vHost'
    read labels
    iterate {

        domain Device

        // Attach to an existing import record
        extract 'Host' set hostName
        lookup 'Name' with hostName

        // Start loading the Host Details
        extract 'Host' transform with replaceAll('.example.com', '') set hostName load 'Name'
        load 'Source Document' with cache.vCenterServerName
        extract 'Object ID' set objectId
        extract '# Cores' load 'Processor - Count'
        extract '# Memory' load 'Memory - Total'
        extract 'Service tag' load 'serialNumber' set serialNo
        extract 'ESX Version' load 'os' set esxVersion
        extract 'Datacenter' set datacenter
        
        // Locate the Room the device is in
        find Room by "location" eq "VMware" and "roomName" eq datacenter into 'roomSource'
        whenNotFound 'roomSource' create {
            "location" 'VMware'
            "roomName" datacenter
        }
        
        // Manufacturer
        extract 'Vendor' set mfg load 'manufacturer'
        find Manufacturer by 'name' eq mfg into 'manufacturer'
        whenNotFound 'manufacturer' create {'name' mfg }

        // Model
        extract 'Model' set model load 'Model'
        find Model by \
            'modelName' eq model \
            and 'manufacturer' eq mfg \
            into 'model'
        elseFind Model by \
            'modelName' eq model \
            into 'model'
        
        // TODO: Waiting on Ticket TM-20132 correcting for this functionality
        // In the meantime, the workaround is to NOT attempt creation of the Model
        // whenNotFound 'model' create {
        //     'modelName' model;
        //     'manufacturer' mfg;
        //     'assetType' 'Server';
        //     'usize' 1 
        // }
        
        // Set some Virtual Properties
        load 'Virtual - Is Virtual' with 'No'
        load 'DSID-VMwareObjectID' with objectId
        extract 'Cluster' transform with prepend('VM Cluster: ') set clusterNameWithLabel load 'Virtual - Cluster Name'
        
        // CPU Model contains a string which is split on @.  Before the @ is the Model, after is the Speed.  Available in TM v4.5
        extract 'CPU Model' set cpuModel
        
        // Create Description
        extract '# NICs' load 'Network - NIC Count' set numNics
        extract '# VMs' set numVMs
        extract '# vCPUs' set numVCpus
        extract 'vRAM' set vRam
        def hostDesc = "Cluster Host (Nics:" + numNics \
            + ", # of VMs:" + numVMs \
            + ", # of vCPUs:" + numVCpus \
            + ", RAM:" + vRam + "MB)"    
        load 'Description' with hostDesc    
        // load 'DSLastSeen-RVTools' with NOW

        // Collect the cached IP, Macs and VLans
        ipSet = cache.deviceIps[hostName]
        macSet = cache.deviceMacs[hostName]
        vlanSet = cache.deviceVLans[hostName]

        // Load each field with the collected list
        load 'IP Address' with ipSet?.join(', ')
        load 'Network - Mac Address' with macSet?.join(', ')
        load 'Network - Source VLAN' with vlanSet?.join(', ')

        // Shorten the IP, Mac and VLans if they're too long
        def ipLen = DOMAIN.ipAddress?.length()
        def ipString = DOMAIN.ipAddress
        if (ipLen > 1000){
            element ipString transform with ellipsis(999) load 'IP Address'
        }
        
        // Test Mac Length
        def macLen = DOMAIN.'Network - Mac Address'?.length()
        def macString = DOMAIN.'Network - Mac Address'
        if (macLen > 255){
            element macString transform with ellipsis(254) load 'Network - Mac Address'
        }

        // Test Mac Length
        def vlanLen = DOMAIN.'Network - Source VLAN'?.length()
        def vlanString = DOMAIN.'Network - Source VLAN'
        if (vlanLen > 255){
            element vlanString transform with ellipsis(254) load 'Network - Source VLAN'
        }

        // Find the Asset
        find Device by \
            'Name' eq hostName \
            and 'Manufacturer' eq mfg \
            and 'Model' eq model \
            and 'External Ref Id' eq objectId \
            into 'id'
        elseFind Device by \
            'Name' eq hostName\
            and 'Manufacturer' eq mfg \
            and 'External Ref Id' eq objectId \
            into 'id'
        elseFind Device by \
            'Name' eq hostName \
            and 'External Ref Id' eq objectId \
            into 'id'
        elseFind Device by \
            'Name' eq hostName \
            and 'Manufacturer' eq mfg \
            and 'Model' eq model \
            into 'id'
        elseFind Device by \
            'Name' eq hostName \
            and 'Manufacturer' eq mfg \
            into 'id'
        elseFind Device by \
            'Name' eq hostName \
            and 'serialNumber' eq serialNo \
            into 'id'
        if (config.matchHostOnNameAlone == true){
            elseFind Device by \
                'Name' eq hostName \
                into 'id'
        }
        set thisHost with DOMAIN

        // Add a Dependency if there is
        extract 'Cluster' set clusterName
        if((config.process.clusters == true) && (clusterName != null) && (clusterName != '')){
            
            domain Application
            load 'Vendor' with config.tmSettings.vmWareMfg
            load 'Name' with clusterNameWithLabel

            find Application by \
                'Name' eq clusterNameWithLabel \
                and 'Vendor' eq config.tmSettings.vmWareMfg \
                into 'id'
            elseFind Application by \
                'Name' eq clusterNameWithLabel \
                into 'id'
            set thisCluster with DOMAIN
            ignore record

            domain Dependency with thisCluster 'Cluster Runs On' thisHost
            
            // Dependency Properties
            load 'status' with 'Validated'
            load 'dataFlowFreq' with 'constant'

            // Comment
            load 'comment' with 'From RV Tools: ' + NOW 
        }
    }
}
    
//////////////////////////////
//  vDisks
//////////////////////////////
if(config.process.vDisk == true){
    

    /*
        Prudential Customization:
        The RD-supplied iterate loop will not be used on this vDisk sheet.
        The replacement iterate simply collects details on if a VM has a Raw disk or not.
        
    */
    
    // iterate {

    //     // Set the domain
    //     domain Storage
        
    //     extract 'VM' set vmName
    //     extract 'Disk' set diskName
    //     extract 'VM ID' set vmID
    //     extract 'VM UUID' set vmUUID
    //     extract 'Path' set path
    //     extract 'Raw' set raw 
        

    //     // Handle Version Specific Column Naming
    //     if(cache.rvToolsFileVersion == '4.1.3.0') {
                
    //         extract 'Capacity MiB'  transform with replaceAll(',','') defaultValue(0) set diskCapacity load 'Space - Provisioned'
    //     } else {            
    //         extract 'Capacity MB'  transform with replaceAll(',','') defaultValue(0) set diskCapacity load 'Space - Provisioned'
    //     }


    //     set dataStoreName with path.substring(1,path.indexOf("]"))
    //     set uniqueDiskName with vmName + '-' + diskName

    //     load 'Name' with uniqueDiskName
    //     load 'Source Document' with cache.vCenterServerName
    //     load 'Scale' with 'MB'
    //     load 'FS Type' with 'VMware vDisk'
    //     // load 'DSLastSeen-RVTools' with NOW

    //     // Find the Asset
    //     find Storage by \
    //         'Name' eq uniqueDiskName \
    //         and 'Space - Provisioned' eq diskCapacity \
    //         and 'FS Type' eq 'VMware vDisk' \
    //         into 'id'
    //     elseFind Storage by \
    //         'Name' eq uniqueDiskName \
    //         and 'FS Type' eq 'VMware vDisk' \
    //         into 'id'
    //     elseFind Storage by \
    //         'Name' eq uniqueDiskName \
    //         and 'Space - Provisioned' eq diskCapacity \
    //         into 'id'
    //     elseFind Storage by 'Name' eq uniqueDiskName into 'id'
    //     set thisDisk with DOMAIN

    //     // Find the VM
    //     domain Device
    //     load 'Name' with vmName
    //     // load 'Manufacturer' with config.tmSettings.vmWareMfg
    //     // load 'Model' with config.tmSettings.vmWareModel
    //     load 'Device Type' with 'VM'
    //     load 'DSID-VMwareObjectID' with vmID
    //     load 'DSID-VMwareUUID' with vmUUID
    //     find Device by 'Name' eq vmName and 'DSID-VMwareObjectID' eq vmID and 'DSID-VMwareUUID' eq vmUUID into 'id'
    //     set thisVM with DOMAIN
    //     ignore record

    //     // Find the Datastore
    //     if(path){
        
    //         set dataStoreName with path.substring(1,path.indexOf("]"))
    //         domain Storage        
    //         load 'Name' with dataStoreName
    //         load 'FS Type' with 'Datastore'
    //         find Storage by 'Name' eq dataStoreName and 'FS Type' eq 'Datastore' into 'id'
    //         set thisDatastore with DOMAIN
    //         ignore record
    //         // Create Dependency   vDisk to vDatastore
    //         domain Dependency with thisDisk 'vDisk-vDatastore' thisDatastore
    //         load 'status' with 'Validated'
    //         load 'dataFlowFreq' with 'constant'
    //         load 'comment' with 'From RV Tools: ' + NOW
    //     }

    //     // Create Dependency   VM to vDisk
    //     domain Dependency with thisVM 'VM-vDisk' thisDisk
    //     load 'status' with 'Validated'
    //     load 'dataFlowFreq' with 'constant'
    //     load 'comment' with 'From RV Tools: ' + NOW


    // }
}

//////////////////////////////
//  VMs
//////////////////////////////
if (config.process.vm == true){
    
    // Read RAW disk data from the vDisk Sheet
    // Store the details in the device cache for later use
    sheet 'vDisk'
    read labels
    
    iterate {
        // Get the VM Name
        extract 'VM' set vmName

        // Extract and handle RAW disk mode
        extract 'Raw' set rawDiskMode

        // If this line is for a RAW disk
        if(rawDiskMode == 'True'){

            // Add this VM name to the list of 'Has Raw Disk Mode'
            cache.devicesWithRawDisk.addAll(vmName)
        }
        
        // Extract and handle Shared Bus data
        extract 'Shared Bus' set sharedBus

        // If this line is for a RAW disk
        if(sharedBus != 'noSharing'){

            // Add this VM name to the list of 'Has Raw Disk Mode'
            cache.devicesWithSharedBus.addAll(vmName)
        }
    }

    // Collect details on the Memory Reservation Locks (Associated to Direct Path I/O tagging)
    sheet 'vMemory'
    read labels
    
    iterate {
        // Get the VM Name
        extract 'VM' set vmName

        // Extract and handle RAW disk mode
        extract 'Memory Reservation Locked To Max' set memoryLockedToMax
        
        // If this line is for a RAW disk
        if(memoryLockedToMax == 'True'){

            // Add this VM name to the list of 'Has Raw Disk Mode'
            cache.devicesWithLockedMemoryAtMax.addAll(vmName)
        }
    }

    // Read CD data from the vCD Sheet
    // Store the details in the device cache for later use
    sheet 'vCD'
    read labels
    
    iterate {
        extract 'Connected' set cdConnected
        extract 'Starts Connected' set cdStartsConnected
        extract 'Device Type' set cdDeviceType

        // If this line is for a RAW disk
        if((cdConnected == 'True' || cdStartsConnected == 'True') && cdDeviceType.substring(0,3) == 'ISO'){

            // Get the VM Name
            extract 'VM' set vmName

            // Add this VM name to the list of 'Has Raw Disk Mode'
            // cache.devicesWithConnectedCDs.addAll(vmName)
            cache.devicesWithConnectedCDs.put(vmName, cdDeviceType)
        }

    }
    
    sheet 'vInfo'
    read labels
    iterate {
        // Set the domain
        domain Device

        // Basic Values
        load 'Source Document' with cache.vCenterServerName
        extract 'VM' load 'Name' set vmName 
        extract 'VM ID' set objectId load 'DSID-VMwareObjectID'
        extract 'Template' set template 
        extract 'DNS Name' load 'Network - Hostname' set dnsName 
        extract 'Powerstate' load 'Virtual - Power State'
        extract 'CPUs' load 'Processor - Count' set cpu
        extract 'Memory' load 'Memory - Total' set memory
        extract 'NICs' load 'Network - NIC Count'
        extract 'Disks' load 'Disks - Count'
        extract 'Datacenter' set datacenter 
        extract 'OS according to the VMware Tools' load 'OS' set os
        extract 'VM UUID' load 'Serial #' set vmUUID
        extract 'Path' set path
        extract 'Host' set host
        if(path != ''){
            set dataStore with path.substring(1, path.indexOf("]"))
        }
        
        load 'Manufacturer' with 'VMware'
        load 'Network - Hostname' with dnsName
        load 'Model' with 'VM'
        load 'Device Type' with 'VM'
        load 'DSID-VMwareUUID' with vmUUID
        load 'Virtual - Is Virtual' with 'Yes'
        extract 'HW version' load 'Virtual - Hardware Version'
        
        extract 'Connection state' load 'Virtual - Connection State'
        extract 'Guest state' load 'Virtual - Guest State'
        extract 'VI SDK Server' load 'Source vCenter' set vCenterServer
        extract 'VM ID' load 'DSID-VMwareObjectID' set vmID
        extract 'Resource pool' load 'Virtual - Resource Pool'
        load 'Validation' with 'Validated'
        // load 'DSLastSeen-RVTools' with NOW
        
        // Add the RDM Disk tag if the VM has a Raw Disk
        if(cache.devicesWithRawDisk.contains(vmName)){
            load 'Disks - Raw Mode' with 'True'
        } else{
            load 'Disks - Raw Mode' with 'False'
        }
    
        // Add the Shared Bus field if the device Shares a bus
        if(cache.devicesWithSharedBus.contains(vmName)){
            load 'Disks - Shares Bus' with 'True'
        } else{
            load 'Disks - Shares Bus' with 'False'
        }
        
        // Add the ISO tag if the VM has a Raw Disk
        if(cache.devicesWithConnectedCDs.keySet().contains(vmName)){
            isoName = cache.devicesWithConnectedCDs[vmName]
            load 'Disks - ISO Attached' with isoName
        } else{
            load 'Disks - ISO Attached' with 'No ISO Attached'
        }
        
        // Handle Version Specific Column Naming
        if(cache.rvToolsFileVersion == '4.1.3.0') {
                
                extract 'Provisioned MiB' load 'Disks - Total Provisioned'
                extract 'In Use MiB' load 'Disks - Total Used'
        } else {            
                extract 'Provisioned MB' load 'Disks - Total Provisioned'
                extract 'In Use MB' load 'Disks - Total Used'
        }
        

        // // Locate the Room the device is in
        find Room by "location" eq "VMware" and "roomName" eq datacenter into 'roomSource'
        whenNotFound 'roomSource' create{
            "location" 'VMware'
            "roomName" datacenter

        }

        // Find the asset
        find Device by \
            'Name' eq vmName \
            and 'Network - Hostname' eq dnsName \
            and 'DSID-VMwareUUID' eq vmUUID \
            and 'DSID-VMwareObjectID' eq objectId \
            and 'Source vCenter' eq vCenterServer \
            into 'id' 
        
        elseFind Device by \
            'Name' eq vmName \
            and 'Network - Hostname' eq dnsName \
            and 'DSID-VMwareObjectID' eq objectId \
            and 'Source vCenter' eq vCenterServer \
            into 'id' 
        
        elseFind Device by \
            'Name' eq vmName \
            and 'Network - Hostname' eq dnsName \
            and 'DSID-VMwareUUID' eq vmUUID \
            and 'Source vCenter' eq vCenterServer \
            into 'id'
        
        elseFind Device by \
            'Name' eq vmName \
            and 'DSID-VMwareObjectID' eq objectId \
            and 'DSID-VMwareUUID' eq vmUUID \
            into 'id'
        
        elseFind Device by \
            'Name' eq vmName \
            and 'DSID-VMwareUUID' eq vmUUID \
            into 'id'

        elseFind Device by \
            'DSID-VMwareObjectID' eq objectId \
            and 'DSID-VMwareUUID' eq vmUUID \
            into 'id'

        if (config.matchVMOnNameAlone == true){
            elseFind Device by \
                'Name' eq vmName \
                into 'id'
        }

        if (FINDINGS.size() == 0) {init 'moveBundle' with config.tmSettings.newDeviceBundleName}  
        if (template == 'True') {load 'moveBundle' with config.tmSettings.templateBundleName}
        set thisVM with DOMAIN

        // Add a Dependency if there is
        extract 'Cluster' set clusterName
        if((config.process.clusters == true) && (clusterName != null) && (clusterName != '')){    
            
            extract 'Cluster' transform with prepend('VM Cluster: ') set clusterNameWithLabel
            
            // Find the "Bottom" Asset
            domain Application
            load 'Name' with clusterNameWithLabel
            load 'Vendor' with config.tmSettings.vmWareMfg
            find Application by 'Name' eq clusterNameWithLabel and 'Vendor' eq config.tmSettings.vmWareMfg into 'id'
            elseFind Application by 'Name' eq clusterNameWithLabel into 'id'
            set thisCluster with DOMAIN
            ignore record
            
            domain Dependency with thisVM 'VM Runs On' thisCluster
            load 'status' with 'Validated'
            load 'dataFlowFreq' with 'constant'
            load 'comment' with 'From RV Tools' + NOW

        } else {
            
            domain Device
            load 'Name' with host
            find Device by 'Name' eq host into 'id'
            set thisHost with DOMAIN
            ignore record

            domain Dependency with thisVM 'VM Runs On' thisHost
            load 'status' with 'Validated'
            load 'dataFlowFreq' with 'constant'
            load 'comment' with 'From RV Tools' + NOW
            
        }

        // Dependency to the Data Store
        // Find the Datastore
        if(config.process.storage == true){

            domain Storage    
            load 'Name' with dataStore
            load 'FS Type' with 'Datastore'    
            find Storage by 'Name' eq dataStore and 'FS Type' eq 'Datastore' into 'id'
            set thisDatastore with DOMAIN
            ignore record

            domain Dependency with thisVM 'VM-vDatastore' thisDatastore
            load 'status' with 'Validated'
            load 'dataFlowFreq' with 'constant'
            load 'comment' with 'From RV Tools: ' + NOW
        }
    }

    // Tab: vCPU - VM Guest Related CPU info
    sheet 'vCPU'
    read labels
    iterate {

        // Set the domain
        domain Device

        extract 'VM ID' set vmID
        lookup 'DSID-VMwareObjectID' with vmID
        if (LOOKUP.found()) {   
            
            extract 'CPUs' load 'Processor - Count'
            extract 'Sockets' load 'Processor - Socket Count'
            extract 'Cores p/s' load 'Processor - Cores Per Proc'
        }
    }

    // Tab: vNetwork - VM Guest Related IP and Mac address info
    sheet 'vNetwork'
    read labels
    iterate {

        // Set the domain
        domain Device

        extract 'VM' set vmName
        extract 'VM ID' set vmID
        lookup 'DSID-VMwareObjectID' with vmID
        if (LOOKUP.found()) {   
            extract 'Adapter' set adaptor
            extract 'Network' set network
            extract 'Mac Address' set macAddress
            load 'Network - Mac Address' transform with append(', ', macAddress)
            
            // Load the Network Adaptor Fields
            load 'Network - Adaptor' transform with append(', ',adaptor)
            load 'Network - vNetwork' transform with append(', ',network)
        
            // Collect IP Addresses
            List ipAddresses = []

            // Handle Version Specific Column Naming
            if(cache.rvToolsFileVersion == '4.1.3.0') {
                    
                extract 'IPv4 Address' set ipv4Address
                extract 'IPv6 Address' set ipv6Address
                
                ipAddresses.add(ipv4Address)
                ipAddresses.add(ipv6Address)

            } else {            
                extract 'IP Address' set ipAddr
                ipAddresses.add(ipAddr)
            }            
            
            // Load the IP Addresses into the field
            load 'IP Address' transform with append(', ', ipAddresses.join(', '))

            
            // Extract and handle Direct IO Path data
            extract 'Direct Path IO' set directIOPath
            
            // If the device has Direct Path IO, and the Memory is locked to the maximum reservation
            if(directIOPath == 'True' && cache.devicesWithLockedMemoryAtMax.contains(vmName)){
                load 'Disks - Direct Path IO' with 'True'
            } else {
                load 'Disks - Direct Path IO' with 'False'
            }
        }
    }

    // Tab: vTools - VM Tools Data for VM Record
    sheet 'vTools'
    read labels
    iterate {
    
        // Set the domain
        domain Device
    
        extract 'VM ID' set vmID
        extract 'VM UUID' set vmUUID
        lookup 'DSID-VMwareObjectID' with vmID
        if (LOOKUP.found()) {    
            extract 'Tools' load 'Virtual - Tools Status'
            extract 'Tools Version' set longToolsVersion
            if(longToolsVersion){
                set toolsVersion with simplifyToolsVersion(longToolsVersion)
                load 'Virtual - Tools Version' with toolsVersion
            }
            
            // Take advantage of this processing loop to fix up the IPs collected
            // during the vNetwork sheet
            
            // Creates the field if it doesn't already exist
            load 'IP Address' transform with append('','')
            load 'Network - Mac Address' transform with append('','')

            // Test IP Length
            def ipLen = DOMAIN.ipAddress.length()
            def ipString = DOMAIN.ipAddress

            if (ipLen > 1000){
                element ipString transform with ellipsis(999) load 'IP Address'
            }

            // Test MAC Length
            def macLen = DOMAIN.'Network - Mac Address'?.length()
            def macString = DOMAIN.'Network - Mac Address'
            if (macLen > 255){
                element macString transform with ellipsis(254) load 'Network - Mac Address'
            }


            // Check the Existing Asset Record for Virtual - Power State and Tools Status
            find Device \
                by 'DSID-VMwareObjectID' eq vmID \
                and 'Serial #' eq vmUUID \
                fetch 'Virtual - Tools Status', 'Virtual - Power State' \
                set deviceRecord

            if(FINDINGS.size() > 0){
                // Check to see if the VM Tools Status has changed
                if(deviceRecord[0].custom29 != DOMAIN.'Virtual - Tools Status'){

                    // Formulate a Comment to add to the Device Record
                    def commentString = 'Tools Status Changed: Previous - ' + deviceRecord[0].custom29 + ', Current - ' + DOMAIN.'Virtual - Tools Status'
                    load 'comments' with commentString 
                    log commentString
                } 
    
                // Check to see if the VM Power State has changed
                if(deviceRecord[0].custom27 != DOMAIN.'Virtual - Power State'){
    
                    // Formulate a Comment to add to the Device Record
                    def commentString = 'Power State Changed: Previous - ' + deviceRecord[0].custom27 + ', Current - ' + DOMAIN.'Virtual - Power State'
                    log commentString
                    load 'comments' with commentString 
    
                } 
            }

        }
    }
}

//////////////////////////////
//  Data Stores
//////////////////////////////
if(config.process.storage == true){
    // Process Tab: vDatastore
    //         This tab is where the Data Stores are listed
    sheet 'vDatastore'
    read labels
    iterate {

        // Set the domain
        domain Storage
        load 'Source Document' with cache.vCenterServerName
        extract 'Name' load 'Name' set datastoreName
        extract 'Hosts' set hosts
        extract 'Cluster name' transform with prepend('VM Cluster: ') set clusterNameWithLabel
        
        // Handle Version Specific Column Naming
        if(cache.rvToolsFileVersion == '4.1.3.0') {
                
            extract 'In Use MiB' transform with replaceAll(',','') defaultValue(0) load 'Space - Used'
            extract 'Capacity MiB' transform with replaceAll(',','') defaultValue(0) load 'Space - Provisioned' set datastoreSize
        } else {            
            extract 'In Use MB' transform with replaceAll(',','') defaultValue(0) load 'Space - Used'
            extract 'Capacity MB' transform with replaceAll(',','') defaultValue(0) load 'Space - Provisioned' set datastoreSize
        }

        load 'Scale' with 'MB'
        load 'FS Type' with 'Datastore'

        // load 'DSLastSeen-RVTools' with NOW

        load 'Bundle' with config.tmSettings.logicalStorageBundleName

        // Find Storage Asset
        find Storage by \
            'Name' eq datastoreName \
            and 'Space - Provisioned' eq datastoreSize \
            and 'FS Type' eq 'Datastore' \
            into 'id'
        
        elseFind Storage by \
            'Name' eq datastoreName \
            and 'FS Type' eq 'Datastore' \
            into 'id'
        
        elseFind Storage by \
            'Name' eq datastoreName \
            and 'Space - Provisioned' eq datastoreSize \
            into 'id'
        set thisDatastore with DOMAIN

        // Add a Dependency if there is
        extract 'Cluster name' set clusterName
        if((config.process.clusters == true) && (clusterName != null) && (clusterName != '')){    
            
            // Top Asset: the Cluster
            domain Application
            load 'Name' with clusterNameWithLabel
            load 'Vendor' with config.tmSettings.vmWareMfg
            find Application by 'Name' eq clusterNameWithLabel and 'Vendor' eq config.tmSettings.vmWareMfg into 'id'
            elseFind Application by 'Name' eq clusterNameWithLabel into 'id'
            set thisCluster with DOMAIN
            ignore record
            
            domain Dependency with thisCluster 'Cluster-vDatastore' thisDatastore
            load 'status' with 'Validated'
            load 'dataFlowFreq' with 'constant'
            load 'comment' with 'From RV Tools: ' + NOW
        }

        if(config.process.hosts == true) {
            // If there is a list, or just a single value
            if (hosts?.contains(',')) {
                def hostList = hosts.split(',')
                for (host in hostList){
                
                    String hostName = host.trim()
                    // This dependency is created 'manually' because it's inside of a loop and reasigning the DOMAIN to a variable more than once is not permitted.
                    domain Dependency
                    load 'asset' with hostName
                    find Device by 'Name' eq hostName into 'asset'
                    whenNotFound 'asset' create {
                        'Name' hostName
                    }
                    
                    load 'dependent' with datastoreName
                    find Storage by 'Name' eq datastoreName and 'FS Type' eq 'Datastore' into 'dependent'
                    elseFind Storage by 'Name' eq datastoreName into 'dependent'
                    whenNotFound 'dependent' create {
                        'Name' datastoreName
                        'FS Type' 'Datastore'
                    }

                    load 'type' with 'VMHost-vDatastore'
                    load 'status' with 'Validated'
                    load 'dataFlowFreq' with 'constant'
                    load 'comment' with 'From RV Tools: ' + NOW
                }

            }else{
                // Single Server Name
                domain Device
                load 'Name' with hosts
                find Device by 'Name' eq hosts into 'id'
                set thisHost with DOMAIN
                ignore record

                domain Dependency with thisHost 'VMHost-vDatastore' thisDatastore
                load 'status' with 'Validated'
                load 'dataFlowFreq' with 'constant'
                load 'comment' with 'From RV Tools: ' + NOW
            }
        }
    }


    //////////////////////////////
    //  Partitions
    //////////////////////////////
    sheet 'vPartition'
    read labels
    iterate {

        // Set the domain
        domain Storage
        
        extract 'VM' set vmName
        extract 'Disk' set diskName
        
        // Handle Version Specific Column Naming
        if(cache.rvToolsFileVersion == '4.1.3.0') {
                
            extract 'Capacity MiB'  transform with replaceAll(',','') defaultValue(0) set diskCapacity load 'Space - Provisioned'
            extract 'Free MiB'  transform with replaceAll(',','')  defaultValue(0) set diskFree
        } else {            
            extract 'Capacity MB'  transform with replaceAll(',','') defaultValue(0) set diskCapacity load 'Space - Provisioned'
            extract 'Free MB'  transform with replaceAll(',','')  defaultValue(0) set diskFree
        }

        set uniqueDiskName with vmName + '-' + diskName

        load 'Name' with uniqueDiskName
        load 'Source Document' with cache.vCenterServerName
        load 'Scale' with 'MB'
        load 'FS Type' with 'VMware vPartition'

        load 'Bundle' with config.tmSettings.logicalStorageBundleName

        // load 'DSLastSeen-RVTools' with NOW

        // Find the Asset
        find Storage by \
            'Name' eq uniqueDiskName \
            and 'Space - Provisioned' eq diskCapacity \
            and 'FS Type' eq 'VMware vPartition' \
            into 'id'
        
        elseFind Storage by \
            'Name' eq uniqueDiskName \
            and 'FS Type' eq 'VMware vPartition' \
            into 'id'
        
        elseFind Storage by \
            'Name' eq uniqueDiskName \
            and 'Space - Provisioned' eq diskCapacity \
            into 'id'
        
        elseFind Storage by 'Name' eq uniqueDiskName into 'id'

        // Create Dependency
        domain Dependency
        
        // Find VM Asset
        load 'asset' with vmName
        find Device by 'Name' eq vmName \
            and 'Manufacturer' eq config.tmSettings.vmWareModel \
            and 'Model' eq config.tmSettings.vmWareModel\
            into 'asset'   // Minimal VM details in this tab to use, not enough to permit creating with name alone
        whenNotFound 'asset' create {
            'Name' vmName
            'Manufacturer' config.tmSettings.vmWareMfg
            'Model' config.tmSettings.vmWareModel
            'Device Type' 'VM'
        }

        // Find "Bottom" Asset
        load 'dependent' with uniqueDiskName
        find Storage by 'Name' eq uniqueDiskName and 'FS Type' eq 'VMware vDisk' into 'dependent'
        whenNotFound 'dependent' create{
            'Name' uniqueDiskName
            'FS Type' 'VMware vDisk'
        }
        load 'type' with 'VM-vPartition'
        load 'status' with 'Validated'
        load 'dataFlowFreq' with 'constant'

        load 'comment' with 'From RV Tools: ' + NOW

    }
}