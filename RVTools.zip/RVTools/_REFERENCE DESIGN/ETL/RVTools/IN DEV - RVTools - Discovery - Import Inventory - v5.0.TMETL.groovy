/*
        Script Name: RVTools - Discovery - Import Inventory - v5.0
        Extension Type: Import Data Script

        SUMMARY
        Import Inventory for a vCenter using an RVTools Excel Export.

        DESCRIPTION
        Import an export of vCenter from an RVTools file.  This import script will create or update matching
        asset records and dependencies.  This highly configurable script offers many different asset classes
        and dependency types.

        RELEASE DETAILS
            Author: TransitionManager Automation Development <support@transitionmanager.com>
            Script Version: v5.0
            Release Date: 2022-01-20

            (c) Copyright 2022 by Transitional Data Services. All Rights Reserved.

        REQUIREMENTS
            Minimum TM Version: 5.0.2
            RVTools Minimum Version: v3.8

            FIELD REQUIREMENTS:
                Application:
                    Used for Types:
                        - vCenter Server
                        - vCenter Cluster

                Device:
                    Used for Types:
                        - VMHosts
                        - VirtualMachines
                        - VirtualMachinesTemplates
                        - VirtualNetworks
                        - VirtualDistributedSwitch

                Storage:
                    Used for Types:
                        - Datastores
                        - vDisks

        CONFIGURATION SETTINGS
            Configuration Overview

            [config]
                dataSource
                    name
                    dataTypes

        TESTING APPROVALS
            - TM Version: {tmVersion}, {testDate}, {Summary}

*/

// Configuration and settings to be used throughout the script
Map config = [

    // Data Source Identification for Tagging assets
    dataSource: [
        name: 'RVTools',

        // Define the Data Types this source represents
        dataTypes: [

            // vCenter Clusters
            cluster: [

                // Include vCenter Clusters
                import: true,

                // Asset Configurations
                type: 'vCenter Cluster',        // Type Labels are Singular
                                                // Used as a Tag

                bundle: 'vCenter Clusters'      // Bundles are Plural

            ],

            // vCenter VMHosts
            host: [
                // Include vCenter VMHosts
                import: true,

                // Asset Configurations
                type: 'vCenter VMHost',         // Type Labels are Singular
                                                // Used as a Tag

                bundle: 'vCenter VMHosts',       // Bundles are Plural

                // If an asset isn't found by all other searches, should a name match be enough?
                matchOnName: true,

            ],

            // vCenter VirtualMachines
            vm: [
                // Include vCenter Clusters
                import: true,

                // Asset Configurations
                type: 'vCenter VM',             // Type Labels are Singular
                                                // Used as a Tag

                bundle: 'DS Inbox - RVTools',   // Bundles are Plural

                // Manufacturer and Model
                manufacturer: 'VMware',
                model: 'VM',

                // If an asset isn't found by all other searches, should a name match be enough?
                matchOnName: true,

                // RV Tools lists 10 'Source Network' Fields
                // Use this group of settings to define 0-10 networks
                // and store them in custom field Device[{prefix} n]
                sourceNetworks: [

                    // Enable and Disable this import feature
                    enabled: true,

                    // Provide the standard prefix part of the field label
                    prefix: 'Source Network',

                    // How many "Source Network"s to read and map as a colum
                    start: 1,   // Default: 1
                    end: 3      // Default: 3

                    // Using Default Settings, your Device will expect 3 fields:
                    //      'Source Network 1'
                    //      'Source Network 2'
                    //      'Source Network 3'
                ]
            ],

            // vCenter VM Templates
            template: [
                // Include vCenter Templates
                import: true,

                // Asset Configurations
                type: 'vCenter Template',       // Type Labels are Singular
                                                // Used as a Tag

                bundle: 'vCenter Templates'     // Bundles are Plural

            ],

            // vCenter vDisks
            vdisk: [
                // Include vCenter vDisks
                import: true,

                // Asset Configurations
                type: 'vCenter vDisk',          // Type Labels are Singular
                                                // Used as a Tag

                bundle: 'vCenter vDisks'        // Bundles are Plural

            ],

            // vCenter vPartitions
            partition: [
                // Include vCenter vPartitions
                import: true,

                // Asset Configurations
                type: 'vCenter vPartition',    // Type Labels are Singular
                                               // Used as a Tag

                bundle: 'vCenter vPartitions'  // Bundles are Plural

            ],

            // vCenter Datastores
            datastore: [
                // Include vCenter Datastores
                import: true,

                // Asset Configurations
                type: 'vCenter Datastore',    // Type Labels are Singular
                                              // Used as a Tag

                bundle: 'vCenter Datastores'  // Bundles are Plural

            ],

            // subnet:
            subnet: [
                // Include vCenter Clusters
                import: false,  // Subnets requires the TM Extension 'Subnets'

                // Asset Configurations
                type: 'Subnet',             // Type Labels are Singular
                                            // Used as a Tag

                bundle: 'Network Subnets'   // Bundles are Plural

            ],
        ]
    ],
]

// A cache object to store data throughout the script's execution
Map cache = [
    rvToolsFileVersion: '',
    sourceDocumentName: '',

    // The newer versions of RVTools that have differing column headers in some cases
    newerRVToolsVersions: [
        '4.1.3.0',
        '4.1.4.0',
    ],

    // Collection of assets
    assets: [
        clusters: [:],
        hosts: [:],
        vms: [:],
        templates: [:],
        vdisks: [:],
        partitions: [:],
        datastores: [:],
        subnets: [:],
    ],
]

//************************************
// Helper Functions
//***********************************/
def simplifyToolsVersion = { longToolsVersion ->
    // Return the trimmed version
    if (lToolsVersion == '2,147,483,647') {
        return 'Open VMTools Version'
    } else {
        return longToolsVersion.tokenize(',')[0]
    }
}

//************************************
// Batch Loading Order
//***********************************/
domain Application
domain Device
domain Database
domain Storage
domain Dependency

//////////////////////////////
//  vMetaData
//////////////////////////////
sheet 'vMetaData'
read labels
iterate {
    // Cache the vCenter server name and RV Tools version to be used later in the script
    extract 'Server' set vMetadataServer
    extract 'RVTools version' set vMetadataRvToolsVersion
    cache.sourceDocumentName = 'RV Tools vCenter Server: ' + vMetadataServer
    cache.rvToolsFileVersion = vMetadataRvToolsVersion
}

// Begin processing each sheet to create objects

// Read VM Records
sheet 'vInfo'; read labels; iterate {

    // Create a VM cached record
    def vm = [
        'VM': SOURCE['VM'],
        'Powerstate': SOURCE['Powerstate'],
        'Template': SOURCE['Template'],
        'Config status': SOURCE['Config status'],
        'DNS Name': SOURCE['DNS Name'],
        'Connection state': SOURCE['Connection state'],
        'Guest state': SOURCE['Guest state'],
        'Heartbeat': SOURCE['Heartbeat'],
        'Consolidation Needed': SOURCE['Consolidation Needed'],
        'PowerOn': SOURCE['PowerOn'],
        'Suspend time': SOURCE['Suspend time'],
        'Creation date': SOURCE['Creation date'],
        'Change Version': SOURCE['Change Version'],
        'CPUs': SOURCE['CPUs'],
        'Memory': SOURCE['Memory'],
        'NICs': SOURCE['NICs'],
        'Disks': SOURCE['Disks'],
        'min Required EVC Mode Key ': SOURCE['min Required EVC Mode Key '],
        'Latency Sensitivity': SOURCE['Latency Sensitivity'],
        'EnableUUID': SOURCE['EnableUUID'],
        'CBT': SOURCE['CBT'],
        'Primary IP Address': SOURCE['Primary IP Address'],
        'Network #1': SOURCE['Network #1'],
        'Network #2': SOURCE['Network #2'],
        'Network #3': SOURCE['Network #3'],
        'Network #4': SOURCE['Network #4'],
        'Num Monitors': SOURCE['Num Monitors'],
        'Video Ram KB': SOURCE['Video Ram KB'],
        'Resource pool': SOURCE['Resource pool'],
        'Folder': SOURCE['Folder'],
        'vApp': SOURCE['vApp'],
        'DAS protection': SOURCE['DAS protection'],
        'FT State': SOURCE['FT State'],
        'FT Latency': SOURCE['FT Latency'],
        'FT Bandwidth': SOURCE['FT Bandwidth'],
        'FT Sec. Latency': SOURCE['FT Sec. Latency'],
        'Provisioned MB': SOURCE['Provisioned MB'],
        'In Use MB': SOURCE['In Use MB'],
        'Unshared MB': SOURCE['Unshared MB'],
        'HA Restart Priority': SOURCE['HA Restart Priority'],
        'HA Isolation Response': SOURCE['HA Isolation Response'],
        'HA VM Monitoring': SOURCE['HA VM Monitoring'],
        'Cluster rule(s)': SOURCE['Cluster rule(s)'],
        'Cluster rule name(s)': SOURCE['Cluster rule name(s)'],
        'Boot Required': SOURCE['Boot Required'],
        'Boot delay': SOURCE['Boot delay'],
        'Boot retry delay': SOURCE['Boot retry delay'],
        'Boot retry enabled': SOURCE['Boot retry enabled'],
        'Boot BIOS setup': SOURCE['Boot BIOS setup'],
        'Firmware': SOURCE['Firmware'],
        'HW version': SOURCE['HW version'],
        'HW upgrade status': SOURCE['HW upgrade status'],
        'HW upgrade policy': SOURCE['HW upgrade policy'],
        'HW target': SOURCE['HW target'],
        'Path': SOURCE['Path'],
        'Log directory': SOURCE['Log directory'],
        'Snapshot directory': SOURCE['Snapshot directory'],
        'Suspend directory': SOURCE['Suspend directory'],
        'Annotation': SOURCE['Annotation'],
        'Datacenter': SOURCE['Datacenter'],
        'Cluster': SOURCE['Cluster'],
        'Host': SOURCE['Host'],
        'OS according to the configuration file': SOURCE['OS according to the configuration file'],
        'OS according to the VMware Tools': SOURCE['OS according to the VMware Tools'],
        'VM ID': SOURCE['VM ID'],
        'VM UUID': SOURCE['VM UUID'],
        'VI SDK Server type': SOURCE['VI SDK Server type'],
        'VI SDK API Version': SOURCE['VI SDK API Version'],
        'VI SDK Server': SOURCE['VI SDK Server'],
        'VI SDK UUID': SOURCE['VI SDK UUID']
    ]

    // Cache the VM Primary record
    cache.assets.vms.put(SOURCE['VM ID'], vm)

}

// Read CPU Values
sheet 'vCPU'; read labels; iterate {
    
    // Collect CPU field
    def cpu = [
        'VM': SOURCE['VM'],
        'Powerstate': SOURCE['Powerstate'],
        'Template': SOURCE['Template'],
        'CPUs': SOURCE['CPUs'],
        'Sockets': SOURCE['Sockets'],
        'Cores p/s': SOURCE['Cores p/s'],
        'Max': SOURCE['Max'],
        'Overall': SOURCE['Overall'],
        'Level': SOURCE['Level'],
        'Shares': SOURCE['Shares'],
        'Reservation': SOURCE['Reservation'],
        'Entitlement': SOURCE['Entitlement'],
        'DRS Entitlement': SOURCE['DRS Entitlement'],
        'Limit': SOURCE['Limit'],
        'Hot Add': SOURCE['Hot Add'],
        'Hot Remove': SOURCE['Hot Remove'],
        'Annotation': SOURCE['Annotation'],
        'Datacenter': SOURCE['Datacenter'],
        'Cluster': SOURCE['Cluster'],
        'Host': SOURCE['Host'],
        'Folder': SOURCE['Folder'],
        'OS according to the configuration file': SOURCE['OS according to the configuration file'],
        'OS according to the VMware Tools': SOURCE['OS according to the VMware Tools'],
        'VM ID': SOURCE['VM ID'],
        'VM UUID': SOURCE['VM UUID'],
        'VI SDK Server': SOURCE['VI SDK Server'],
        'VI SDK UUID': SOURCE['VI SDK UUID']
    ]

    // Cache the VM Primary record
   cache.assets.vms[SOURCE['VM ID']].cpu = cpu

}

def JSON = new com.tdssrc.grails.JsonUtil()
console on

log JSON.toPrettyJson(cache)
